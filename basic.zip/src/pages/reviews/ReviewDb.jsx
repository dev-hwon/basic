const data = [
  { id: "1", title: "예약이 어려워요", score: 92 },
  { id: "2", title: "규모가 작어요", score: 92 },
  { id: "3", title: "선생님이 너무 잘생겼어요", score: 92 },
  { id: "4", title: "진료비가 너무 은혜로워요", score: 92 },
  { id: "5", title: "의자가 다 썩었어요", score: 92 },
];
export { data };
