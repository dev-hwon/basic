import React from "react";

export default function GlobalFooter() {
  return <footer>footer area</footer>;
}
