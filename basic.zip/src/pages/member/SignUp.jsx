import React from "react";

export default function SignUp() {
  return <div>회원가입스~~</div>;
}
