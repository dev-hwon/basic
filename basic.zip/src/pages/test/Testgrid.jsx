import React from "react";

export default function Testgrid() {
  return (
    <>
      <div className="col_wrap col_gap_16">
        <div className="col col_3">
          <div className="testBox"></div>
        </div>
        <div className="col col_3">
          <div className="testBox"></div>
        </div>
        <div className="col col_3">
          <div className="testBox"></div>
        </div>
        <div className="col col_3">
          <div className="testBox"></div>
        </div>
      </div>
      <div className="col_wrap col_gap_16">
        <div className="col col_4">
          <div className="testBox"></div>
        </div>
        <div className="col col_4">
          <div className="testBox"></div>
        </div>
        <div className="col col_4">
          <div className="testBox"></div>
        </div>
      </div>
      <div className="col_wrap col_gap_16">
        <div className="col col_3">
          <div className="testBox"></div>
        </div>
        <div className="col col_3">
          <div className="testBox"></div>
        </div>
        <div className="col col_3">
          <div className="testBox"></div>
        </div>
        <div className="col col_3">
          <div className="testBox"></div>
        </div>
      </div>
    </>
  );
}
