import React from 'react';

export default function PageGuard( {children} ) {
    // const { user } = useAuth();
    // const router = useRouter();
    // const pageAuthPromise = usePageAuth(user, router.asPath);
    
  //  useEffect(() => {
        // pageAuthPromise.then(function(obj) {
        //     if (obj && obj.data) {
        //         const data = obj.data;
        //         if (data.status === 'fail') {
        //             // swal("권한이 없습니다");
        //             router.push("/dashboard/permissionDenied");
        //         }
        //     }
        // });
 //   }, [router, user]);

    // return (
    //     <React.Fragment>{children}</React.Fragment>
    // );
  );
}
