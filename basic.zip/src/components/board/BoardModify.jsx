import React from "react";

export default function BoardModify() {
  return <div>board</div>;
}
