export { headerSetting, buttonTexts };
const headerSetting = {
  start: "title", //start :  end :
  // center: "",
  end: "prevYear,prev,today,next,nextYear timeGridDay,timeGridWeek,dayGridMonth,listWeek", //"dayGridMonth", // 버튼 역시 월별 캘린더만 남도록 나머지 삭제
};

const buttonTexts = {
  today: "오늘",
  month: "월",
  week: "주",
  day: "일",
  list: "리스트",
};
